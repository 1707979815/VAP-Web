<div align="center">

# 🎬 Custom VAP

**A lightweight, WebGL-powered video animation player (VAP / VAPX) for Vue 3 & modern web.**

Real-time RGB/Alpha channel compositing · VAPX fusion-layer image/text replacement · Precise frame rendering · Full TypeScript types

[简体中文](./README.md) | **English**

[![npm version](https://img.shields.io/npm/v/custom-vap.svg)](https://www.npmjs.com/package/custom-vap)
[![npm downloads](https://img.shields.io/npm/dm/custom-vap.svg)](https://www.npmjs.com/package/custom-vap)
[![bundle size](https://img.shields.io/bundlephobia/minzip/custom-vap)](https://bundlephobia.com/package/custom-vap)
[![license](https://img.shields.io/npm/l/custom-vap.svg)](./LICENSE)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-blue.svg)](https://www.typescriptlang.org/)

<br>

**[🔗 Live Demo](https://1707979815.github.io/VAP-Web/)** — single-instance playground, multi-instance stress page, VAPX slot replacement

</div>

---

## ✨ Features

| Feature | Description |
| --- | --- |
| 🎞️ **Alpha compositing** | Composites the RGB and Alpha channels of an MP4 on the GPU, so one file plays as a transparent animation. |
| 🧩 **VAPX fusion layer** | Overlays image / text slots on the video and replaces them at runtime. |
| 🎯 **Precise frames** | Driven by `requestVideoFrameCallback` (rVFC), with an automatic fallback to `requestAnimationFrame`. |
| 🖼️ **Image replacement** | Swap a fusion-layer image without re-exporting the VAP (URL or local resource). |
| 📝 **Text injection** | Replace text layers while the animation is playing. |
| 👆 **Slot clicks** | Per-slot and global click callbacks inside the composited frame. |
| 💾 **Persistence** | Caches parsed VAP config in IndexedDB to avoid repeated downloads and parsing. |
| 👀 **Visibility** | Shared `IntersectionObserver`; pause or skip rendering when off-screen. |
| 🎬 **Frame range** | Play any frame range with a custom loop count, and freeze on an exact frame. |
| 🌐 **Multi-format** | ESM / CJS / UMD builds, ready for bundlers, npm and `<script>` tags. |
| 🎯 **TypeScript first** | Complete `.d.ts`; every option, event payload and record is typed. |

### Format support

- ✅ Tencent VAP / VAPX — the MP4 carries a top-level `vapc` box with plain JSON (`{ info, src, frame }`).
- ❌ YYEVA — **not** compatible: its JSON lives in the MP4 metadata (`mergeinfo`) and is zlib + base64 compressed with a different schema. Supporting it needs a separate adapter.

---

## 📥 Installation

```bash
# npm
npm install custom-vap

# yarn
yarn add custom-vap

# pnpm
pnpm add custom-vap
```

### CDN (no bundler)

```html
<!-- unpkg -->
<script src="https://unpkg.com/custom-vap@latest/dist/index.umd.js"></script>

<!-- jsDelivr -->
<script src="https://cdn.jsdelivr.net/npm/custom-vap@latest/dist/index.umd.js"></script>

<script>
  const vap = new CustomVap(document.getElementById('stage'), { autoplay: true });
  vap.load('/path/to/video.mp4');
</script>
```

---

## 🚀 Quick start

### Vue 3

```vue
<template>
  <div ref="container" class="vap-stage"></div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue';
import { CustomVap } from 'custom-vap';

const container = ref<HTMLDivElement>();
let player: CustomVap | null = null;

onMounted(async () => {
  if (!container.value) return;

  player = new CustomVap(container.value, {
    autoplay: true, // play as soon as loading finishes
    loop: 0,        // 0 = infinite
  });

  // Multiple listeners per event
  player.on('start', () => console.log('start'));
  player.on('process', ({ frame }) => console.log('frame', frame));
  player.on('end', () => console.log('end'));

  // Single-slot listeners: onLoad / onReady / onStart / onPause / onResume /
  // onLoop / onStop / onEnd / onError / onVisible / onDestroy
  // (no single-slot form for process / webglcontext*).
  // Calling again replaces the previous callback and returns an unsubscribe fn.
  const offEnd = player.onEnd(({ frame }) => console.log('ended at frame', frame));

  await player.load('/path/to/video.mp4');
});

onBeforeUnmount(() => {
  player?.destroy();
});
</script>

<style scoped>
.vap-stage {
  width: 300px;
  height: 300px;
}
</style>
```

### Vanilla JavaScript

```javascript
import { CustomVap } from 'custom-vap';

const player = new CustomVap(document.getElementById('stage'), { loop: 3 });

await player.load('/path/to/video.mp4');
player.play();
```

### Passing your own `<canvas>`

```javascript
// Use an existing canvas element
const player = new CustomVap(canvasEl, { loop: 0 });
await player.load('/path/to/video.mp4');
player.play();
```

> **Display size is your CSS's job.** With a canvas passed in, the library does not touch inline styles: it only sizes the drawing buffer from the canvas's layout size (`clientWidth/Height`) × DPR, and it does not letterbox (use `aspect-ratio` / `object-fit` for that).
>
> It also does **not** observe that canvas for size changes — writing `canvas.width` would re-trigger the resize callback and create a feedback loop. Call `player.resize()` yourself when the parent changes size.
>
> Always give the canvas a definite CSS size. Without one, the layout size follows the `width`/`height` attributes, and on HiDPI screens "attribute pixels × DPR" makes it grow on every resize.

```css
/* Recommended: fixed-ratio container, canvas fills it */
.stage { width: 100%; aspect-ratio: 16 / 9; }
.stage > canvas { width: 100%; height: 100%; display: block; }
```

---

## 📚 API

### `new CustomVap(el, options?)`

Creates a player instance. Pass a `div` and the canvas is created and managed for you; pass a `canvas` and it is used directly.

| Parameter | Type | Required | Description |
| --- | --- | --- | --- |
| el | `HTMLDivElement \| HTMLCanvasElement` | ✅ | Mount container or canvas element |
| options | `VapOptions` | ❌ | Initial config |

#### VapOptions

| Option | Type | Default | Description |
| --- | --- | --- | --- |
| `loop` | `number` | `1` | Loop count (`0` or negative = infinite) |
| `autoplay` | `boolean` | `false` | Play as soon as loading finishes |
| `muted` | `boolean` | `false` | Mute the audio track |
| `volume` | `number` | `1.0` | Volume (`0`–`1`) |
| `fps` | `number` | — | Target frame rate; defaults to the video's own fps |
| `endFrameMode` | `'Forward' \| 'Backward' \| 'Clearward'` | `'Backward'` | End behaviour: stay on the last frame / return to the first / clear the canvas |
| `dataPersistence` | `boolean` | `false` | Cache the parsed VAP config in IndexedDB |
| `enableBlob` | `boolean` | `true` | Play through a Blob URL |
| `isPreciseFrame` | `boolean` | `true` | Use rVFC precise frames (falls back to a per-instance rAF loop) |
| `isClickable` | `boolean` | `false` | Enable VAPX slot click events |
| `invisibleBehavior` | `'pause' \| 'skip'` | `'skip'` | When off-screen: auto-pause, or keep the timeline and skip painting |
| `defaultPoster` | `string` | — | Poster image URL shown while idle, after `Clearward`, or when loading fails |
| `fusionEdge` | `'linear' \| 'smooth'` | `'linear'` | Fusion-layer mask curve: `linear` multiplies the authored alpha; `smooth` hardens edges (useful for noisy masked mp4s) |
| `fusionAlphaBoost` | `number` | `1` | Fusion-layer alpha gain; `> 1` looks more solid, for special looks only |

> **Fusion-layer default change**: up to 1.1.0 the mask curve was hard-coded to `smoothstep(0.01, 0.95) × 1.8`, which lifted a 0.5 mask to ~0.93. The default is now a straight multiply (`fusionEdge: 'linear'` + `fusionAlphaBoost: 1`), matching the artwork and the official VAP player — **the fusion layer will look lighter than before**. To restore the old look, pass `{ fusionEdge: 'smooth', fusionAlphaBoost: 1.8 }` explicitly.

#### Instance methods

| Method | Description |
| --- | --- |
| `load(url)` | Load and parse a VAP video. Returns `Promise<this>`. |
| `play(loop?)` | Start playback; `loop` overrides the config. Returns `Promise<this>`. |
| `playRange(startFrame, endFrame, loop?)` | Play a frame range. Returns `Promise<this>`. |
| `seek(frame)` | Freeze on a specific frame (1-based). Pauses first if playing; afterwards `playState` is `PAUSED`. Returns `Promise<this>`. |
| `pause()` | Pause playback. |
| `resume()` | Resume playback. |
| `stop()` | Stop playback; the final frame follows `endFrameMode`. Idempotent when already stopped. |
| `destroy()` | Destroy the instance and release video / WebGL / event resources. |
| `resize()` | Recompute the drawing buffer from the container size and DPR. |
| `setImage(tag, url)` | Replace a fusion-layer image by URL. Returns `Promise<this>`. |
| `setText(tag, text)` | Replace a fusion-layer text layer. |
| `setDynamicResources(headData)` | Batch-set dynamic resources, with `[tag]` wildcard matching. Returns `Promise<this>`. |
| `updateOptions(newOptions)` | Merge config at runtime; `defaultPoster` refreshes/clears the poster, `fusionEdge` / `fusionAlphaBoost` redraw the current frame immediately. |
| `skipRender(skip?)` | Suspend/resume painting while the timeline keeps running. |
| `on(event, cb)` / `off(event, cb)` | Multiple listeners per event. Returns `this`. |
| `onLoad` / `onReady` / `onStart` / `onLoop` / `onPause` / `onResume` / `onStop` / `onEnd` / `onError` / `onVisible` / `onDestroy` | Single-slot listeners; calling again replaces the callback and returns an unsubscribe function. |
| `onClick(srcTag, cb)` / `onAllClick(cb)` | Slot click handlers. |

> Read-only: `currentFrame` — current frame number (1-based, same convention as `playRange` / `seek`).

#### Events

| Event | Payload | When |
| --- | --- | --- |
| `load` | `{ url, config }` | Video loaded and parsed |
| `ready` | `{ currentTime }` | Video is playable (`canplaythrough`) |
| `start` | `{ currentTime }` | Playback started |
| `process` | `{ frame, currentTime }` | Emitted for every rendered frame |
| `loop` | `{ currentTime, loopCount }` | Each time the animation wraps to the start (`loopCount` starts at 2) |
| `pause` | `{ currentTime }` | Playback paused |
| `resume` | `{ currentTime }` | Playback resumed |
| `stop` | `{ currentTime }` | Playback stopped (**synchronous**; `currentTime` is the value before the freeze-frame seek) |
| `end` | `{ currentTime, frame }` | Playback ended (always after `stop`) |
| `error` | `{ error, code, message, tips }` | Load / playback failure; `error` is a structured `VAPError` |
| `webglcontextlost` | `{ message }` | WebGL context lost |
| `webglcontextrestored` | `{ message }` | WebGL context restored |
| `visible` | `{ isVisible, playState }` | Container visibility changed |
| `destroy` | `{ currentTime, playState }` | Emitted before resources are released |

---

## 🎯 Advanced usage

### 1. Play a frame range

```javascript
// Play frames 10–50, loop 3 times
await player.playRange(10, 50, 3);
```

### 2. Replace an image layer

```javascript
await player.setImage('avatar', 'https://example.com/new-avatar.png');
```

### 3. Inject text

```javascript
player.setText('username', 'VIP user');
```

### 4. Batch dynamic resources

```javascript
// `[tag]` wildcards resolve against headData
await player.setDynamicResources({
  username: 'DreamLife',
  avatar: 'https://example.com/avatar.png',
});
```

### 5. Slot click events

```javascript
const player = new CustomVap(container, { isClickable: true });

player.onClick('avatar', () => console.log('avatar clicked'));

player.onAllClick(({ srcId, srcTag, frame }) => {
  console.log('slot clicked:', srcId, srcTag, frame);
});
```

### 6. Visibility optimisation

```javascript
const player = new CustomVap(container, {
  invisibleBehavior: 'pause', // pause off-screen, resume when back
  // invisibleBehavior: 'skip', // keep the timeline, skip painting (default)
});
```

### 7. End behaviour

```javascript
const player = new CustomVap(container, {
  endFrameMode: 'Forward',    // return to the first frame
  // endFrameMode: 'Backward',  // stay on the last frame (default)
  // endFrameMode: 'Clearward', // clear the canvas
});
```

> **Event ordering**: `stop` is synchronous; the `Backward` / `Forward` freeze frame is painted later in `seeked` (`Clearward` clears + shows the poster). Do **not** screenshot or read pixels inside the `stop` callback — wait roughly one frame after `stop` for the final image.

### 8. Update config at runtime

```javascript
player.updateOptions({ muted: true, loop: 0 });
```

### 9. Errors

Every load / playback / render failure surfaces as a `VAPError` (`Error` subclass) with a stable `code`, so you never match on message strings:

| Field | Description |
| --- | --- |
| `code` | Stable error code (see below) |
| `message` | Diagnostic detail, prefixed with `[VAP error] ` (includes URL / HTTP status) |
| `tips` | Ready-to-display hint (stable Chinese copy with a suggested action) |
| `cause` | Original error, if any |

| Code | When | Typical handling |
| --- | --- | --- |
| `NETWORK` | fetch threw or HTTP non-2xx | retry after checking the network |
| `PARSE_FAILED` | no `vapc` box, corrupt JSON, empty config | invalid asset — replace it |
| `NOT_LOADED` | `play()` / `resume()` before `load()` | fix the call order |
| `INVALID_FRAME_RANGE` | `playRange` end ≤ start | fix the arguments |
| `VIDEO_ERROR` | `<video>` network / decode failure | replace the asset |
| `AUTOPLAY_BLOCKED` | audible autoplay blocked (including the muted retry) | require a user gesture, or init with `muted: true` |
| `WEBGL_UNSUPPORTED` | no WebGL context | fall back to a static image |
| `WEBGL_CONTEXT_LOST` | context lost (also emits `webglcontextlost`) | wait for `webglcontextrestored` |
| `POSTER_LOAD_FAILED` | `defaultPoster` failed to load | check the image URL |
| `DYNAMIC_RESOURCE_FAILED` | `setImage` slot image failed | check the resource URL |
| `CACHE_FAILED` | IndexedDB write failed (playback unaffected) | ignore |
| `UNSUPPORTED_ELEMENT` | constructor argument is neither div nor canvas | fix the argument |

```javascript
import { isVAPError } from 'custom-vap';

// Via the event (payload already exposes code / message / tips)
player.on('error', ({ code, message, tips, error }) => {
  if (code === 'NETWORK') return retryLater();
  if (code === 'AUTOPLAY_BLOCKED') return showTapToPlay();
  showToast(tips);
  report(code, message, error.cause);
});

// Promise rejections carry the same VAPError
try {
  await player.load(url);
} catch (err) {
  if (isVAPError(err) && err.code === 'PARSE_FAILED') markBrokenAsset(url);
}
```

---

## 📊 At a glance

| Scenario | How it is handled |
| --- | --- |
| Precise frames | rVFC where supported, otherwise an independent rAF per instance |
| Persistence | Parsed config cached in IndexedDB; the second load is instant |
| Context loss | Automatically rebuilds shaders and textures after `webglcontextrestored` |
| Multiple instances | One shared visibility observer; render loops stay independent |
| Autoplay blocked | Automatically retries muted |
| Structured errors | Every failure carries `code` / `tips` / `cause` for reporting, retry and fallback |

---

## 🌐 Browser support

| Feature | Minimum |
| --- | --- |
| WebGL rendering | Any modern browser with WebGL 1.0+ |
| rVFC precise frames | Chrome / Edge 87+ (falls back to rAF) |
| IntersectionObserver visibility | Chrome / Edge 51+, Firefox 55+, Safari 12.1+ |
| IndexedDB persistence | All modern browsers (skipped when unavailable) |

---

## 🔧 FAQ

<details>
<summary><b>Q: Nothing renders after loading?</b></summary>

- Make sure the container has a non-zero size **at `load` time**.
- The player calls `resize()` on `load` / `play` / context restore, and watches the container in `div` mode.
- With a canvas passed in, size changes are not watched and styles are untouched: call `player.resize()` yourself (`transform: scale` is not a size change).

</details>

<details>
<summary><b>Q: Autoplay is blocked?</b></summary>

The player retries muted when the browser blocks audible autoplay. You can also start muted explicitly:

```javascript
const player = new CustomVap(container, { autoplay: true, muted: true });
```

</details>

<details>
<summary><b>Q: How do I play only part of the animation?</b></summary>

```javascript
// frames 1–30, loop twice
await player.playRange(1, 30, 2);
```

</details>

<details>
<summary><b>Q: What happens on WebGL context loss?</b></summary>

Nothing to do: the player listens for `webglcontextlost` / `webglcontextrestored`, rebuilds programs, buffers and textures, and emits the corresponding events.

</details>

<details>
<summary><b>Q: Pause when scrolled out of view?</b></summary>

```javascript
const player = new CustomVap(container, { invisibleBehavior: 'pause' });
```

</details>

---

## 🤝 Contributing

PRs and issues are welcome. Please make sure:

- Code style stays consistent (TypeScript strict)
- `npm run build:rollup` succeeds before committing
- Open an issue to discuss significant changes first

## 📄 License

MIT © 2026 [DreamLife(Zhou)](https://github.com/1707979815)

## 🙏 Acknowledgements

- [VAP](https://github.com/Tencent/vap) — Tencent video cloud animation format (VAP / VAPX)

---

<div align="center">

**⭐ If this project helps you, please [star it on GitHub](https://github.com/1707979815/VAP-Web) — it keeps the project going.**

</div>
